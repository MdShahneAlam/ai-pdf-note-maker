import { createContext } from "react";

export const FileSaveContext=createContext();